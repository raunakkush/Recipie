const mongoose = require("mongoose");

const recipeSchema = new mongoose.Schema({
  name: String,
  imageUrl: String,
  description: String,
  shortDescription: String,
  process: String,
  ingredients: [{ name: String, amount: String }],
  ratings: [Number]
});

module.exports = mongoose.model("Recipe", recipeSchema);
